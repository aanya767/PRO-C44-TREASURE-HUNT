class System{

    constructor(){}




    authenticate(actualCode,enteredCode){
        if(actualCode === enteredCode)
        return true
    else
        return false
    }

    


}